create
    definer = root@localhost procedure LOGOUTALL()
BEGIN
    DECLARE CurrentToken VARCHAR(32);

    WHILE( EXISTS(SELECT * FROM ACCESSTOKENS) ) DO
        SELECT Token INTO CurrentToken FROM ACCESSTOKENS LIMIT 1;
        CALL LOGOUT(CurrentToken);
    END WHILE;
END;

