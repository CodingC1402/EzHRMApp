create
    definer = root@localhost procedure LOGOUT(IN AccessToken decimal)
BEGIN
    IF (EXISTS (SELECT * FROM AccessTokens WHERE Token = AccessToken)) THEN
        UPDATE TAIKHOAN TK
        SET TK.DangLogin = 0
        WHERE TK.TaiKhoan = (SELECT TaiKhoan FROM AccessTokens WHERE Token = AccessToken);

        DELETE FROM ACCESSTOKENS WHERE AccessToken = Token;
    END IF;
END;

