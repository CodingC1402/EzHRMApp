create
    definer = root@localhost procedure LOGOUT(IN AccessToken varchar(32))
BEGIN
    IF (EXISTS (SELECT * FROM AccessTokens WHERE Token = AccessToken)) THEN
        UPDATE TAIKHOAN TK
        SET TK.DangLogin = 0
        WHERE TK.TaiKhoan = (SELECT T.Account FROM AccessTokens T WHERE Token = AccessToken LIMIT 1);

        DELETE FROM ACCESSTOKENS WHERE AccessToken = Token;
    END IF;
END;

