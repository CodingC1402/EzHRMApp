create
    definer = root@localhost procedure LOGOUT(IN Username varchar(255), IN LoginPassword varchar(255))
BEGIN
    DECLARE AccountCount TINYINT;

    SELECT COUNT(*) INTO AccountCount FROM TAIKHOAN TK WHERE Username = TK.TaiKhoan AND LoginPassword = TK.Password;
    IF (AccountCount > 0) THEN
        UPDATE TAIKHOAN TK
        SET TK.DangLogin = 0
        WHERE TK.TaiKhoan = Username AND LoginPassword = TK.Password;

        DELETE FROM ACCESSTOKENS WHERE Account = Username;
    END IF;
END;

